public class Unpackaged {
    private Unpackaged() {}

    public int method1OfUnpackaged(final int arg1, final int arg2) {
        return 0;
    }

    public int method2OfUnpackaged(final int arg) {
        return 0;
    }
}
