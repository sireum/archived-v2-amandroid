package package1;

public class A {
    private A() {}

    public int method1OfA(final int arg1, final int arg2) {
        return 0;
    }

    public int method2OfA(final int arg) {
        return 0;
    }
}
