package package1;

public class B {
    private B() {}

    public int method1OfB(final int arg1, final int arg2) {
        return 0;
    }

    public int method2OfB(final int arg) {
        return 0;
    }
}
