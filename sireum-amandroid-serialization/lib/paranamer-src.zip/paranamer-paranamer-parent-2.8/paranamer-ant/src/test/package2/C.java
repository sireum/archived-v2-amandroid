package package2;

public class C {
    private C() {}

    public int method1OfC(final int arg1, final int arg2) {
        return 0;
    }

    public int method2OfC(final int arg) {
        return 0;
    }
}
