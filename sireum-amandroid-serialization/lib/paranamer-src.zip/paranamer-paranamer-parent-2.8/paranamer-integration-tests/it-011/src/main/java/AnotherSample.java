public class AnotherSample extends ASample {

    public void anotherSampleMethod(String one, Long two) {
        //
    }

}

